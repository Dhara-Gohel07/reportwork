from tkinter import *
import mysql.connector
from tkinter import messagebox
mydb=mysql.connector.connect(
    host="localhost",
    username="root",
    password="",
    database="demo"
)
mycursor=mydb.cursor()
root=Tk()
frame=Frame(root)
frame.pack()
def clear():
    Name.delete(0,END)
    City.delete(0,END)
def searchdata():
    id1=id.get().strip()
    if not id1:
        messagebox.showerror("crud","Enter Id for Search")
        return
    sql="select * from stud where rlno=%s"
    val=(id1,)
    mycursor.execute(sql,val)
    myresult=mycursor.fetchall()
    if len(myresult)==1:
        for x in myresult:
            clear()
            Name.insert(0,x[1])
            City.insert(0,x[2])
    else:
        Name.focus()
        clear()
        id.delete(0,END)
        messagebox.showerror("crud","ENter one id")
    
def insertdata():
    id1=id.get()
    nm=Name.get()
    city=City.get()
    if not id1 or not nm or not city:
        messagebox.showerror("crud","Enter Id for Search")
        return
    sql="Insert into stud(rlno,name,city) Values (%s,%s,%s)"
    val=(id1,nm,city)
    mycursor.execute(sql,val)
    mydb.commit()
    row=mycursor.rowcount
    if row == 1:
        messagebox.showinfo("crud","inserted")
        clear()
    else:
        messagebox.showerror("crud","Not insertred")
        Name.focus()
        clear()

def updatedata():
    id1=id.get()
    nm=Name.get()
    city=City.get()
    if not id1 or not nm or not city:
        messagebox.showerror("crud","Enter Id for Search")
        return
    sql="Update stud set  name=%s,city=%s where rlno = %s"
    val=(nm,city,id1)
    mycursor.execute(sql,val)
    mydb.commit
    row=mycursor.rowcount
    if row == 1:
        messagebox.showinfo("crud","updated")
        clear()
    else:
        messagebox.showerror("crud","Not updated")
        Name.focus()
        clear()

def deletedata():
    id1=id.get()
    if not id1:
        messagebox.showerror("crud","Enter Id for Search")
        return
    sql="delete from stud where rlno=%s"
    val=(id1,)
    mycursor.execute(sql,val)
    mydb.commit()
    row=mycursor.rowcount
    if row == 1:
        messagebox.showinfo("crud","deleted")
        clear()
    else:
        messagebox.showerror("crud","Not deleted")
        Name.focus()
        clear()
Label(frame,text="Enter id for search:",fg="red").grid(row=7,column=0)
id=Entry(frame)
Button(frame,text="Search",command=searchdata,fg="green",activebackground="pink").grid(row=10,column=0)
id.grid(row=7,column=5)
Label(frame,text="Enter Name:").grid(row=17,column=0)
Name=Entry(frame)
Name.grid(row=17,column=5)
Label(frame,text="Enter City:").grid(row=27,column=0)
City=Entry(frame)
City.grid(row=27,column=5)
Label(frame,text="").grid(row=29,column=0)
Button(frame,text="Insert",command=insertdata,fg="green",activebackground="pink").grid(row=30,column=0)
Button(frame,text="Update",command=updatedata,fg="green",activebackground="pink").grid(row=30,column=1)
Button(frame,text="Search",command=deletedata,fg="green",activebackground="pink").grid(row=30,column=5)

root.mainloop()